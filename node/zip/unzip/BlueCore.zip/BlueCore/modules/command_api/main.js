function request(ctx){
    let data =  {
        "name":"sdvoe",
        "vesion":"1.0.0"
    }
    ctx.liguodata.SetStatusSuccess();
    ctx.liguodata.SetData({"data":data});
}


module.exports = request;