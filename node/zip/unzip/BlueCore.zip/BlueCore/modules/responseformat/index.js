class ResponsrFormat{
    constructor(){
        this.status = "FAILED";
        this.result={};
        this.process = [];
        this.error = null;
        this.Timestamp = null;
    }
    SetCommand(value){
        this.result.command= value;
    }
    SetStatusSuccess(){
        this.status="SUCCESS";
    }
    SetData(value){
        this.result.data=value;
    }
    SetTimeStamp(){
        this.Timestamp= Date.now();
    }
    SetErrorInfo(value){
        this.error = value;
    }
    SetProcess(value){
        this.process.push(value);
    }
    SetProcessHead(value){
        this.process.unshift(value);
    }
}
module.exports = ResponsrFormat;