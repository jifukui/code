const path = require("path");

const Koa = require("koa");
const jwt = require("koa-jwt");
const static = require('koa-static-cache')
const LRU = require('lru-cache');
const Route = require("@koa/router");
const bodyParser = require('koa-bodyparser');
const logger = require('koa-logger');


const api = require("./modules/command_api/main");
const response = require("./modules/responseformat/index");

let files = new LRU({ max: 100 })
const app = new Koa();
const router = new Route();
app.use(logger());
app.use(async (ctx,next)=>{
    console.dir(ctx.request)
    if(ctx.url==="/"){
        ctx.redirect("login.html");
    }
    if(ctx.method==="POST"){
        ctx.liguodata = new response();
    }
    // console.log(ctx);
    await next().catch((err)=>{
        if(ctx.method==="POST"){
            ctx.liguodata.SetErrorInfo(err.message);
        }else{
            if(err.status==401){
                ctx.body=err.message
            }
        }
    });
    if(ctx.status===404){
        // ctx.redirect("login.html");
    }else if((ctx.status/100)==5 && ctx.method==="POST"){
        ctx.status = 200;
        ctx.liguodata.SetErrorInfo("Have something wrong");
    }
    if(ctx.method==="POST"){
        let command = {};
        try{
            command.type = ctx.request.body.command.type;
            command.command = ctx.request.body.command.command;
            ctx.liguodata.SetCommand(command);
        }catch(err){
        }finally{
            ctx.liguodata.SetTimeStamp();
            ctx.status = 200;
            ctx.body = ctx.liguodata;
        }
    }
});
app.use(jwt({getToken,secret}).unless({
    path:["/login.html",
    "/axios.js",
    "/login",
    "/api",
    "/upload",
    "/favicon.ico",
    "/login_back.jpg",
    "/jquery-3.5.1.min.js",
    "/login1.html",
    RegExp("^/css/*"),
    RegExp("^/js/*"),
    RegExp("^/fonts/*"),
    RegExp("/*.html$"),
    ]
}));
app.use(static(path.join(__dirname,"static"),{
    maxAge:24*60*60,
    buffer:true,
    gzip:true,
    usePrecompiledGzip:true,
    dynamic:true,
    preload:true
},files));
app.use(bodyParser({}));
app.use(router.routes());
router
    .get("/",()=>{
    })
    .post("/api",async(ctx,next)=>{
        await api(ctx);
        await next();
    })
    .post("/upload",async(ctx,next)=>{
        // console.log(ctx.request);
        // let file = ctx.request.files;
        // console.dir(file);
        
        await next();
    })
app.listen(8000,(err)=>{
});

app.on("error",(err)=>{
})

function getToken(ctx,opt){
    if(ctx.header.sessionid){
        return ctx.header.sessionid;
    }else{
        ctx.throw(401, 'Authorization error');  
    } 
}
function secret(head,body){
    let flag = false;
    let name,id;
    try{
        name = body.name;
        id = body.jti
    }catch(err){
        flag =true;
    }finally{
        if(!flag){
            let pid=datacore.user.get(name);
            if(id===pid){
                return "486e26c3afca7058";
            }
        }
    }
}


