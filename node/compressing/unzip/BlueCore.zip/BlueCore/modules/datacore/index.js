const DataBase = require("../database/index");
const jws = require("jws");
const sdvoe = require("../device/sdvoe/main");
const config = require("../../Config");
const dataCore = {};
dataCore.version = "2.14.2"
dataCore.user = new Map();
let database = null ;
async function DataBaseInit(){
    database = new DataBase(config.ip,config.databaseport);
    let flag = false;
    await database.Init().then(()=>{
        console.log(`data base good`);
        database = database.Data.db("sdvoe");
    },err=>{
        console.log(`data base error ${err}`);
        flag = true;
    }).catch(err=>{
        console.log(`the data base is ${err}`);
    })
}

dataCore.login =async function(ctx){
    const data = ctx.request.body.user;
    ctx.liguodata.SetProcess({"handler":Date.now()});
    if(dataCore.user.has(data.name)){
        console.log("have login");
    }else{
        await database.Data.collection("Users").findOne({name:data.name}).then((docs)=>{
            if(docs){
                let value = {};
                let time = Date.now()
                value.loginTime =time //new Date().toLocaleString();
                if(docs.password==data.password){
                    console.log("登录成功");
                    value.sessionid=jws.sign({
                        header:{
                            alg:"HS256",
                            typ:"JWT"
                        },
                        payload:{
                            iss:"jifukui",
                            name:data.name,
                            jti:time
                        },
                        secret:"486e26c3afca7058"
                    });
                    dataCore.user.set(data.name,time);
                    ctx.liguodata.SetStatusSuccess();
                    ctx.liguodata.SetData({"sessionid":value.sessionid});
                }else{
                    console.log("密码错误")
                }
            }else{
                //没有此用户
                console.log("没有此用户")
            }
        },(err)=>{
            console.log("have error");
        })
    }
    console.log(`what is happend ${dataCore.user.has(data.name)}`)
}
dataCore.logout =async function(ctx){
    const data = ctx.request.body.user;
    if(!dataCore.user.has(data.name)){
        console.log("have no login");
    }else{
        let loginfo={};
        loginfo.loginTime =dataCore.user.get(data.name);
        loginfo.ip = ctx.ip.slice(ctx.ip.lastIndexOf(":")+1);
        loginfo.logoutTime =Date.now() //new Date().toLocaleString();
        await database.Data.collection("Users").findOneAndUpdate({name:data.name},{$push:{history:loginfo}}).then((res)=>{
            if(res.ok==1){
                ctx.liguodata.SetStatusSuccess();
                dataCore.user.delete(data.name);
            }    
        },(err)=>{
            console.log("have error");
        })
    }
    console.log(`${dataCore.user.has(data.name)}`);
}
dataCore.sdvoe = async function(ctx){
    const data = ctx.request.body;
    let command = data.command.command;
    let type = data.command.type;
    type = type.slice(0,1).toLocaleUpperCase()+type.substr(1,2);
    if(((sdvoe[command])||(command=type+command,sdvoe[command]))&&typeof sdvoe[command] === "function"){
        console.log("have this command");
        console.log(command);
        await sdvoe[command](data.command.data,ctx,database);
        // ctx.liguodata.SetStatusSuccess(); 
        // console.dir(ctx.liguodata);
    }else{
        console.log("have not this command");
        ctx.liguodata.SetErrorInfo("no this cmd");
    }
}
dataCore.sdvoeinit = function(){
    sdvoe.Init(database);
}
dataCore.Init =async function(){
    await DataBaseInit();
    this.sdvoeinit();
}
module.exports = dataCore;