const net = require("net");
const DataCore = require("./Device");
const config = require("../../../Config");
const command = []; 
let info="";
let time = Date.now();
let start = 0;
let deviceMap = new Map();
let server = net.connect(config.sdvoeport,config.ip);
let eventSet = new Set(); 
let database = null;
async function DeviceInit(data){
    database = data;
    Init();
    setInterval(() => {
        if(command.length>0){
            let data=command.shift();
            Send(data);
        }
    }, 20);
    setInterval(() => {
        if(eventSet.size>0){
            eventSet.forEach(value=>{
                command.push(`get ${value} device`);
            });
            eventSet.clear();
        }
    }, 200);
    server.on("data",(msg)=>{
        info +=msg;
        let tem=info.indexOf("\r",start);
        if(tem>-1){
            let endtime = Date.now();
            tiem = endtime;
            let value =info.slice(0,tem+1);
            info=info.slice(tem+2,info.length);
            let flag = false;
            try{
                let str=value.slice(0,tem);
                data=JSON.parse(str);
                commandHandle(data);
            }catch(err){
                flag = true;
                console.log("have error "+err);
                info = value + info;
            }finally{
                if(!flag){
                    start = 0;
                }
            }
        }else{
            start = info.length;
        }
    });
}
function Send(msg){
    console.log(`The send info is ${msg} \r\n`);
    server.write(`${msg}\r\n`);
}
function Init(){ 
    command.push("version");
    command.push("require blueriver_api 3.0.0.0");
    command.push("mode async on");
}

function commandHandle(data){
    console.log("the info type is "+data.status);
    switch(data.status){
        case "SUCCESS":{
            if(data.result&&data.result.devices){
                let device = data.result.devices;
                let len = device.length;
                for(let i = 0;i < len;i++){
                    Datahandle(device[i]);
                }     
            }
            else{
                console.log(`have not get the data `);
            }
            break;
        }
        case "ERROR":{
            console.log("Have Error ");
            break;
        }
        case "NOTIFICATION":{
            if(data&&data.result.events.length>0)
            {
                let value = data.result.events;
                for(let i = 0;i < value.length;i++){
                    let info = deviceMap.get(value[i].device_id);
                    switch(value[i].event_type){
                        case "DEVICE_CONNECTED":{
                            if(info)
                            {
                                console.log(`login device have connected`);
                            }else{
                                
                            }
                            let dev = new DataCore(value[i].device_id,database);
                            deviceMap.set(value[i].device_id,dev);
                            command.push(`request ${value[i].request_id}`); 
                            break;
                        }
                        case "DEVICE_INFO_AVAILABLE":{
                            command.push(`request ${value[i].request_id}`);
                            break;
                        }
                        case "DEVICE_DISCONNECTED":{
                            deviceMap.delete(value[i].device_id);
                            break;
                        }
                        case "SETTINGS_CHANGED":{
                            eventSet.add(value[i].device_id);
                            break;
                        }
                        case "REQUEST_COMPLETE":{
                            break;
                        }
                        default :{
                            console.log(`have another event ${value[i].event_type}`);
                        }
                    }
                }
            }
            break;
        }
        case "PROCESSING" :{
            command.push(`request ${data.request_id}`);
            break;
        }
        default:{
            console.log("Have another info");
        }
    }
}
async function Datahandle(data){
    let name = data.device_id;
    console.log(`Get device ${name} info success`);
    let info = deviceMap.get(name);
    if(info){
        switch(info.status){
            case "connected":{
                info.GetDiff(data);
                if(info.deviceinfo.baseinfo.USBactive==true)
                {
                    info.USBinfoInit(data);
                }
                info.StatusChange("available");
                break;
            }
            case "available":{
                info.GetDiff(data);
                console.log(`info.type is ${info.deviceinfo.baseinfo.type}`)
                await database.collection("jidevice").findOneAndUpdate({"baseinfo.id":info.deviceinfo.baseinfo.id},{$set:{"HDMI.0":info.deviceinfo.HDMI[0]}}).then((doc)=>{
                    console.log("good   change database")
                },(err)=>{
                    console.log("databse error");
                }).catch(err=>{
                    console.dir(err);
                })
                break;
            }
            case "unknow":{
                // console.dir(database);
                await database.collection("device").findOne({"device_id":name}).then((doc)=>{
                    if(doc){
                        info.deviceinfo = doc;
                        info.StatusChange("connected");
                    }else{
                        info.StatusChange("register");
                    }
                    
                },(err)=>{
                    console.log("error")
                    console.dir(err);
                });
                deviceMap.set(name,info);
                break;
            }
            case "register":{
                info.DeviceRegister(data);
                if(info.deviceinfo.baseinfo.USBactive==true)
                {
                    info.USBinfoInit(data);
                }
                await database.collection("jidevice").insertOne(info.deviceinfo).then((doc)=>{  
                });
                info.StatusChange("available");
                let value = info.GetStaticinfo();
                
                await database.collection("nextdevice").insertOne(value).then((doc)=>{  
                });
                break;
            }
        }
        
    }
}
function DataBaseInfoGet(dim,src){

}
function ObjectCopy(dim,src){
    for(let val in src){
        if(typeof src[val] === "object"){
            if(Array.isArray(src[val])){
                dim[val] = src[val].slice(0);
            }else{
                dim[val] = {};
                ObjectCopy(dim[val],src[val]);
            }
        }else{
            dim[val] = src[val];
        }
    }
}
function Destory(){
    console.log(`have connect ${server.localPort}`);
    server.destroy();
    process.exit(0);
}

module.exports= {DeviceInit,deviceMap};


