const net_UDP  = require('dgram');


class USBObj{
	#USBInfo_msg=Buffer.from([0x2f,0x03,0xf4,0xa2,0x00,0x00,0x00,0x00,0x03,0x00]);
	#USBcmd_head=[0x2f,0x03,0xf4,0xa2];
	#USBcmd_pair=[0x03,0x02];
	#USBcmd_unpair=[0x03,0x03];

	constructor(data,mac,ip,database){
	    let iip=[];
	    this.ip_addr_hex=ip;
	    for(let i=0;i<ip.length;i++){
	        iip.push(ip[i]);
	    }
	    ip=iip.join(".");
		this.data=data;
		this.database = database
	    this.UDP_port= 6137;
	    this.ip_addr=ip;
	    this.MAC =mac;
		this.USB_program =false;//USB升级状态，刚注册时应该是false 
		this.pair_dev_type=null;
		this.pair_device_id=null;
	    this.DeviceBind(this.data);
		this.CreatSocket(database);
		
	}

	 DeviceBind(data){
        let device_mac="";
        let decode=null;
        this.device_mac=data.device_id;
        this.decode=data.is_transmitter;
    }
//创建UDP
    CreatSocket(database){
        this.server = net_UDP.createSocket("udp4");
        this.server.connect(this.UDP_port,this.ip_addr,(err)=>{
            if(err){
                console.log("USB UDP Create Have error "+err);
            }
            else
            {
				console.log("USB UDP Create Success");
                this.GetPairStatus();  
            }
        });
		let that =this;
        this.server.on("message",(data)=>{
            console.log(`Receive info   The ${that.ip_addr}  USB Data is ${data.toString("hex")}`);
			let value=data.length;
			console.log(`USB cmd type  ${data[9]}`);
			switch(data[9]){
				case 0:{
					break;
				}
				case 1:{
					if(value===11){
						this.pair_status="false";
						console.log(`没有绑定`);
					}else
					{
						this.pair_status = "true";
						this.pair_mac_addr=data.slice(11);
						console.log(`以绑定`);
					}
					
					database.collection("jidevice").findOneAndUpdate({"baseinfo.id":this.device_mac},{"$set":{"USB.pair.pair_status":this.pair_status}}).then((doc)=>{
						console.log(`USB   good   change database `);
					},(err)=>{
						console.log("databse error");
					}).catch(err=>{
						console.dir(err);
					})

	

					break;
				}
				case 2:{
					break;
				}
				case 3:{
					break;
				}
				case 8:{
					break;
				}
				default:{
					break;
				}
			}         
		});
		
    }
	//销毁UDP
	DestroySocket(){
		console.log(`udp close ${this.ip_addr}`);
		this.server.close();
	};
	GetUSBinfoFromDB(){
		if(0)
		{
			this.USB_alias=alias;// 别名
			this.USB_type=USB_type;//USB 模式
			this.pair_status="true";//绑定状态
			
			this.pair_device_id=pair_device_id;//绑定的设备的设备ID
			this.pair_dev_type=pair_dev_type;//绑定的USB的设备类型
			this.pair_ip_addr_hex=pair_ip_addr_hex;//16进制 IP地址 
			this.pair_ip_addr=pair_ip_addr;//绑定设备的USB IP
			this.pair_mac_addr=pair_mac_addr;//绑定设备的USB MAC
		}
		else
		{
			this.USB_alias=this.Device_ID;//默认别名是设备MAC
			if(this.decode==1)
				this.USB_type="LOCAL";//USB模式  解码器是LOCAL 编码器是REMOTE
			else
				this.USB_type="REMOTE";
			this.pair_status="false";//绑定状态
			//等待USB绑定后去更新其他
		}
	};
	
	//设备绑定USB设备
	USBPairDevice(mac_addr){
		let supper =this;
        if(this.pair_status)
        {
            this.USBUnpairDevice();
			setTimeout(function(){
				supper.GetPairStatus();
			},10,supper);
        }
		let status = new Promise(function(res,rej){
			setTimeout(function(){
				//console.log(`${supper.ip_addr} paired status is ${supper.paired}`)
				if(supper.pair_status){
					rej();
				}else{
					res(mac_addr);
				}
			},100,supper);
		});
		status.then(function(mac_addr){
			//console.log(`${supper.ip_addr} 绑定成功  value is ${value.toString("hex")}`);
			let data=supper.#USBcmd_head;
			for(let i=0;i<supper.ip_addr_hex.length;i++){
	        	data=data.concat(supper.ip_addr_hex[i]);
	    	}
			data=data.concat(supper.#USBcmd_pair);
			for(let i=0;i<mac_addr.length;i++){
	        	data=data.concat(mac_addr[i]);
	    	}
			//console.log(`${supper.ip_addr} send data is ${data}`)
			data=Buffer.from(data);
			supper.server.send(data);
			supper.GetPairStatus();
		},function(){
			console.log("绑定失败");
		}).catch(err=>{
			console.log("have error 111111111111111111111");
			console.dir(err);
		})
		
	};
	//设备解绑 已绑定设备
	USBUnpairDevice(){
		if(!this.pair_status)
        {
            return ;
        }
        let data=this.#USBcmd_head;
        for(let i=0;i<this.ip_addr_hex.length;i++){
	        	data=data.concat(this.ip_addr_hex[i]);
	    }
        data=data.concat(this.#USBcmd_unpair);
        for(let i=0;i<this.pair_mac_addr.length;i++){
	        	data=data.concat(this.pair_mac_addr[i]);
	    }
        data=Buffer.from(data);
        this.server.send(data);
        this.pair_status="false";
        this.pair_mac_addr=[];
	};
	//获取当前设备USB绑定状态
	GetPairStatus(){
        this.server.send(this.#USBInfo_msg);
    }
	//设置USB别名
	SetUSBalias(name){
		this.USB_alias=name;
	};
	//获取USB别名
	GetUSBalias(){
		return this.USB_alias;
	};
	
	//修改USB 模式
	ModifyUSBDeviceType(type){
		//API 设置
		this.USB_type=type;
	};
}

module.exports = USBObj;