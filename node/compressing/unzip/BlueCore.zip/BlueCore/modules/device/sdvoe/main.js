const {DeviceInit:Monitor,deviceMap} = require("./monitor");
const net = require("net");
const config = require("../../../Config");

let info="";
let start = 0;
command = []; 
const sdvoe ={};
let handler = new Map(); 
let ji = [];
async function cmd(value){
    let cmd =value
    return new Promise(function(res,rej){
        ji.push(value);
        let data ={};
        server_Send(value);
        data.res=res;
        data.rej=rej;
        handler.set(value,data);
    }).then((value)=>{
        handler.delete(cmd);
        return Promise.resolve(value);
    })
}
function cmdhand(msg){
    info +=msg;
    let i = 0;
    while(1){
        let tem=info.indexOf("\r",0);
        if(tem>-1){
            i++;
            let value =info.slice(0,tem+1);
            info=info.slice(tem+1,info.length);
            let flag = false;
            let str;
            try{
                str=value.slice(0,tem);
            }catch(err){
                flag = true;
                console.log("have error 1 "+err);
                info = value + info;
            }finally{
                if(!flag){
                    start = 0;
                    let value  = ji.shift();
                    let command = handler.get(value);
                    command.res(str);
                }
            }
        }else{
            start = info.length;
            break;
        }
    }
}
async function blueriver_api_init()
{
    server = net.connect(config.sdvoeport,config.ip);
    server.on("connect",async ()=>{
        server_Init();
    });
    server.on("data",cmdhand);
    // server.on("data",(msg)=>{
    //     info +=msg;
    //     let tem=info.indexOf("\r",0);
    //     if(tem>-1){
    //         let value =info.slice(0,tem+1);
    //         info=info.slice(tem+1,info.length);
    //         let flag = false;
    //         try{
    //             let str=value.slice(0,tem);
    //             // console.log(str);
    //             data=JSON.parse(str);
    //             commandHandle(data);
    //         }catch(err){
    //             flag = true;
    //             console.log("have error 1 "+err);
    //             info = value + info;
    //         }finally{
    //             if(!flag){
    //                 start = 0;
    //             }
    //         }
    //     }else{
    //         start = info.length;
    //     }
    // })
}
function server_Send(msg){
    console.log(`The send info is ${msg} \r\n`);
    server.write(`${msg}\r\n`);
}
function server_Init(){
    cmd(`require blueriver_api 3.0.0.0`).then(value=>{
        //value 是发送命令的返回结果
    });
}
//这里待定 和数据监控部分有重复
function commandHandle(data){
    switch(data.status){
        case "SUCCESS":{
            if(data.result&&data.result.devices){  
            }
            else{
                console.log(`have not get the data `);
            }
            break;
        }
        case "ERROR":{
            console.log("Have Error ");
            break;
        }
        case "NOTIFICATION":{
            if(data&&data.result.events.length>0)
            {
                console.log("the device have changed");
                let value = data.result.events;
                for(let i = 0;i < value.length;i++){
                  //  let info = deviceMap.get(value[i].device_id);
                    switch(value[i].event_type){
                        case "SETTINGS_CHANGED":{
                        //    eventSet.add(value[i].device_id);
                            break;
                        }
                        case "REQUEST_COMPLETE":{
                            break;
                        }
                        default :{
                            console.log(`have another event ${value[i].event_type}`);
                        }
                    }
                }
            }
            break;
        }
        case "PROCESSING" :{
            break;
        }
        default:{
            console.log("Have another info");
        }
    }
}
function sever_Destory(){
    server.destroy();
}

//以下为设备设置类操作   
//获取设备信息
function get_device_info(val,ctx,database)
{

}
//视频切换
sdvoe.videoswitch=async function (val,ctx,database)
{
    //join 命令未使能的流 需要先start
    // let {identity:{firmware_version,is_receiver}}=val;
    // let info = deviceMap.get(name);
    let encode=val.in;
    let decode=val.out;
    let info= deviceMap.get(val.in);
  //  console.dir(val);
    await  cmd(`join ${encode}:HDMI:0 ${decode}:0 `);
  //  if(info.deviceinfo.HDMI[0].stream[0].config.afv==true)
    {
        //Afv模式 切换对应音频

    }
    ctx.liguodata.SetStatusSuccess(); 
}
// 音频切换
sdvoe.audioswitch=async function (val,ctx,database)
 {
    //  "data":{
    //      “in”:
    //          {
    //              “type”:“HDMI”
    //              “id”:”zzzzz”,
    //          }
    //      “out”:
    //          {
    //              “type”:“HDMI”
    //              “id”:”zzzzz”,
    //              "index":xxxx,
    //          }
    //      }

     //判断编解码
    await cmd(`join ${val.in.id}:${val.in.type}:0 ${val.out.id}:0 `);
    if(val.out.type=="HDMI_AUDIO")
        await cmd(`set ${val.out.id} property nodes[HDMI_ENCODER:0].inputs.configuration.source.value ${val.out.index} `);
    else if(val.out.type=="STEREP_AUDIO"){
        await cmd(`set ${val.out.id} property nodes[ANALOG_AUDIO_OUTPUT:0].inputs[main:0].configuration.source.value ${val.out.index} `);
    }
    ctx.liguodata.SetStatusSuccess(); 
}
// 编码器3.5音频方向设置
sdvoe.SetaudioDir=async function(val,ctx,database)
{
    //  "data":
    //      {
    //          “id”:”zzzzz”,
    //          "dir":xxxx,
    //      }
    //判断编解码  对于编码器3.5音频可以为输出 是本地环出音频 需要设置方向
    if(val.dir=="OUTPUT")
    {
        await   cmd(`set ${val.id} property nodes[ANALOG_AUDIO_INPUT_OUTPUT:0].configuration.direction OUTPUT}`);
        await   cmd(`set ${val.id} property nodes[ANALOG_AUDIO_INPUT_OUTPUT:0].inputs[main:0].configuration.source.value 2}`);
    }
    else{
        await  cmd(`set ${val.in.id} property nodes[ANALOG_AUDIO_INPUT_OUTPUT:0].configuration.direction INPUT}`);
    }
    ctx.liguodata.SetStatusSuccess(); 
}
// USB切换
sdvoe.USBswitch=async function (val,ctx,database)
{
    // "data":{
    //     “in”:“xxxxxx”,
    //     “out”:[“wewqeweq”],
    // } 

    info_out = deviceMap.get(val.out);
    info_in = deviceMap.get(val.in);
    await info_out.dev_usb.USBPairDevice(info_in.USB.USBmac);
    await info_in.dev_usb.USBPairDevice(info_out.USB.USBmac);
    ctx.liguodata.SetStatusSuccess(); 
}
// wall模板创建
sdvoe.CreateVideoWall=async function(val,ctx,database)
{
    await database.collection("VideoWall").findOne({"name":val.name}).then((doc)=>{
        if(doc){
            //返回错误 已经存在
            ctx.liguodata.SetErrorInfo("VideoWall database has exist");
        }else{
            database.collection("VideoWall").insertOne(val).then((doc)=>{  
                ctx.liguodata.SetStatusSuccess(); 
            });
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// wall模板删除
//删除模板后  已切换的怎么办
sdvoe.DeleteVideoWall=async function (val,ctx,database)
{
    await database.collection("VideoWall").deleteOne({"name":val.name}).then((doc)=>{
    if(doc){
        //删除模板后  已切换的怎么办    
        ctx.liguodata.SetStatusSuccess(); 
    }else{
        ctx.liguodata.SetErrorInfo("VideoWall database not exist");
    }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// wall模板修改
//已经设置的设备要重新设置
sdvoe.ModifyVideoWall=async function(val,ctx,database)
{
    await database.collection("VideoWall").findOne({"name":val.prename}).then((doc)=>{
        if(doc){
            database.collection("VideoWall").findOne({"name":val.name}).then((doc)=>{
                if(doc){
                    ctx.liguodata.SetErrorInfo("VideoWall database has exist");
                }else{
                    delete val.prename;
                    database.collection("VideoWall").findOneAndUpdate({"name":val.prename},val).then((doc)=>{  
                        ctx.liguodata.SetStatusSuccess(); 
                    });
                }
            });    
        }else{
            ctx.liguodata.SetErrorInfo("VideoWall database not exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
}
// wall模板查看
sdvoe.GetVideoWall=async function(val,ctx,database)
{
    await database.collection("VideoWall").findOne({"name":val.name}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetData(doc);
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo("VideoWall database has exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// 视频墙切换
// 如果切换一个没有信号的怎么处理？
//注意 墙的限制条件，偏移和大小只能是偶数，且注意不要越界；
sdvoe.VideoWallswitch=async function (val,ctx,database)
{
    await database.collection("VideoWall").findOneAndUpdate({"name":val.name},{"$set":{"origin":val.in}}).then((doc)=>{
        if(doc){
                doc.layout.forEach(value=>{
                    let info = deviceMap.get(val.in);
                    if(info.deviceinfo.baseinfo.type==0)
                    {
                        let keep_W=0;
                        let keep_H=0;
                        let offset_W=0;
                        let offset_H=0;
                        let wall_output_fps=info.deviceinfo.HDMI[0].source[0].info.signal.video.frames_per_second;
                        if(value.layout.top==0)
                        {
                            keep_H=(info.deviceinfo.HDMI[0].source[0].info.signal.video.height)*100/value.layout.height-value.bezel.bottom;
                            offset_H=0;
                        }
                        else{
                            if(value.layout.top+value.layout.height==100)
                                keep_H=(info.deviceinfo.HDMI[0].source[0].info.signal.video.height)*100/value.layout.height-value.bezel.bottom-value.bezel.top;
                            else
                            keep_H=(info.deviceinfo.HDMI[0].source[0].info.signal.video.height)*100/value.layout.height-value.bezel.top;
                            offset_H=(info.deviceinfo.HDMI[0].source[0].info.signal.video.height)*100/value.layout.height+value.bezel.top;;
                        }

                        if(value.layout.left==0)
                        {
                            keep_W=(info.deviceinfo.HDMI[0].source[0].info.signal.video.width)*100/value.layout.width-value.bezel.right;
                            offset_W=0;                          
                        }  
                        else{
                            if(value.layout.width+value.layout.left==100)
                                keep_W=(info.deviceinfo.HDMI[0].source[0].info.signal.video.width)*100/value.layout.width-value.bezel.left-value.bezel.rigth;
                            else
                                keep_W=(info.deviceinfo.HDMI[0].source[0].info.signal.video.width)*100/value.layout.width-value.bezel.left;
                            offset_W=(info.deviceinfo.HDMI[0].source[0].info.signal.video.width)*100/value.layout.width+value.bezel.left;;
                        }           
                        cmd(`join ${val.in}:HDMI:0 ${value.device}:0 ${val.mode} \
                        size ${value.output.width} ${value.output.height} \
                        keep ${keep_W} ${keep_H} offset ${offset_W} ${offset_H} fps ${wall_output_fps}`);
                    
                    }
            });
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo("VideoWall database has exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
}
// // 单个视频墙信息获取
// //数组中的某一项 是否存在 查询回来的是什么？
// sdvoe.GetDeviceVideoWall=function(val,ctx,database)
// {
//     database.collection("VideoWall").findOne({"device":val.device}).then((doc)=>{
//         if(doc){
//             ctx.liguodata.SetData(doc);//需要返回数组中的一项
//         }else{
//             //返回错误 数据库不存在
//             ctx.liguodata.SetErrorInfo("VideoWall database has exist");
//         }
//     },(err)=>{
//         console.log("error")
//         console.dir(err);
//     });
    
// }
// // 单个视频墙信息设置
// //数组中的某一项 是否存在  一个设备只能存在一个数据库中
// sdvoe.SetDeviceVideoWall=function(val,ctx,database)
// {
//     database.collection("VideoWall").findOneAndUpdate({"device":val.device},val).then((doc)=>{
//         if(doc){
//                 //执行实际墙动作，如果有信号
//         }else{
//             ctx.liguodata.SetErrorInfo("VideoWall database not exist");
//         }
//     },(err)=>{
//         console.log("error")
//         console.dir(err);
//     });
    
// }
// multiview设置
// multi view模板创建 可能需要一个英文或数字的别名 用于画布名称
//使用时间戳 对模板名 multi+时间戳
sdvoe.CreateMultiview=async function (val,ctx,database)
{
    await database.collection("Multiview").findOne({"name":val.name}).then((doc)=>{
        if(doc){
            //返回错误 已经存在
            ctx.liguodata.SetErrorInfo("Multiview database has exist");
        }else{
            let curtime = Date.now();
            let layoutname='multiv'+curtime;
            val.layoutname=layoutname;
            database.collection("Multiview").insertOne(val).then((doc)=>{  
                //执行  创建layout windows
                cmd(`layout ${doc.layoutname} create size ${val.surface.width} ${val.surface.width}`);
                let num=0;
                doc.layout.forEach(value=>{
                    num++;
                    cmd(`layout ${doc.layoutname} window ${num} position ${value.left}  ${value.top} \
                     size  ${value.width} ${value.height} target ${value.z-index}`);
                });
                ctx.liguodata.SetStatusSuccess(); 
            });
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// Multiview模板删除
//删除模板后  已切换的怎么办
sdvoe.DeleteMultiview=async function (val,ctx,database)
{
    await database.collection("Multiview").deleteOne({"name":val.name}).then((doc)=>{
        if(doc){
            cmd(`layout ${doc.layoutname} delete`);
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            ctx.liguodata.SetErrorInfo("Multiview database not exist");
    
        }
        },(err)=>{
            console.log("error")
            console.dir(err);
        });
    
}
// Multiview模板修改
//已经设置的设备要重新设置
sdvoe.ModifyMultiview=async function (val,ctx,database)
{
    await database.collection("Multiview").findOne({"name":val.prename}).then((doc)=>{
        if(doc){
            database.collection("Multiview").findOne({"name":val.name}).then((doc)=>{
                if(doc){
                    ctx.liguodata.SetErrorInfo("Multiview database has exist");
                       
                }else{
                    delete val.prename;
                    database.collection("Multiview").findOneAndUpdate({"name":val.prename},val).then((doc)=>{  
                    //执行  创建layout windows
                        cmd(`layout ${doc.layoutname} create size ${val.surface.width} ${val.surface.width}`);
                        let num=0;
                        doc.layout.forEach(value=>{
                            num++;
                            cmd(`layout ${doc.layoutname} window ${num} position ${value.left}  ${value.top} \
                            size  ${value.width} ${value.height} target ${value.z-index}`);
                        });

                    });
                    ctx.liguodata.SetStatusSuccess(); 
                }
            });    
        }else{
            ctx.liguodata.SetErrorInfo("Multiview database not exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// Multiview模板查看
sdvoe.GetMultiview=async function (val,ctx,database)
{
    await database.collection("Multiview").findOne({"name":val.name}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetData(doc);
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo("Multiview database has exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// Multiview模板切换 可能存在一对多 一个模板对应多个显示器  在设备结构体中保存
sdvoe.Multiviewswitch=async function (val,ctx,database)
{
    await database.collection("Multiview").findOne({"name":val.name}).then((doc)=>{
        if(doc){
        //更新设备信息数据库  编码器切换状态
                doc.layout.forEach(value=>{
                    //let info = deviceMap.get(val.in); 
                    cmd(`start ${value.origin}:HDMI:1`);
                    cmd(`set ${value.origin} scaler size ${value.width} ${value.height}`);
                    cmd(`set ${value.origin} property  nodes[SCALER:0].inputs[main:0].configuration.source.value 1`);
                    cmd(`set ${val.out} multiview pip_MxN fps ${doc.output.fps} size ${doc.output.width} ${doc.output.height} `);
                    cmd(`join ${value.origin}:HDMI:1 ${val.out}:${value.z-index}`);
            });
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo("Multiview database has exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}



// 组创建
sdvoe.CreateGroup=async function(val,ctx,database)
{
    await database.collection("Group").findOne({"name":val.name}).then((doc)=>{
        if(doc){
            //返回错误 已经存在
            ctx.liguodata.SetErrorInfo("Group database has exist");
        }else{
                database.collection("Group").insertOne(val).then((doc)=>{  
                //执行  创建layout windows
                ctx.liguodata.SetStatusSuccess(); 
            });
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// 组删除
//删除后  已切换的怎么办
sdvoe.DeleteGroup=async function(val,ctx,database)
{
    await database.collection("Group").deleteOne({"name":val.name}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            ctx.liguodata.SetErrorInfo("Group database not exist");
        }
        },(err)=>{
            console.log("error")
            console.dir(err);
        });
    
}
// 组修改
sdvoe.ModifyGroup=async function(val,ctx,database)
{
    await database.collection("Group").findOne({"name":val.prename}).then((doc)=>{
        if(doc){
            database.collection("Group").findOne({"name":val.name}).then((doc)=>{
                if(doc){
                    ctx.liguodata.SetErrorInfo("Group database has exist");
                       
                }else{
                    delete val.prename;
                    database.collection("Group").findOneAndUpdate({"name":val.prename},val).then((doc)=>{  
                        ctx.liguodata.SetStatusSuccess(); 
                    });
                }
            });    
        }else{
            ctx.liguodata.SetErrorInfo("Group database not exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// 组查看
sdvoe.GetGroup=async function(val,ctx,database)
{
    await database.collection("Group").findOne({"name":val.name}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetData(doc);
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo("Group database has exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// 组切换
//切换模式？？ 保持当前输出模式 还是可以强制设置？
sdvoe.groupswitch=async function(val,ctx,database)
{
    await database.collection("Group").findOne({"name":val.name}).then((doc)=>{
        if(doc){
                doc.device.forEach(value=>{
                    //更新设备信息数据库  编码器切换状态
                    cmd(`join ${val.in}:HDMI:0 ${value}:0 ${val.mode}`);
            });
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo("Group database has exist");
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}

// 切换场景保存
sdvoe.SaveSwitchScene=function(val,ctx,database)
{

    
}
// 切换场景应用
sdvoe.ApplySwitchScene=function(val,ctx,database)
{

    
}
// 设备备份
sdvoe.SaveBackup=function(val,ctx,database)
{

    
}
// 设备备份应用
sdvoe.ApplyBackup=function(val,ctx,database)
{

    
}



// 设置设备EDID
sdvoe.SetEDID=async function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    if(info.deviceinfo.baseinfo.type==0)
    {
        await cmd(`set ${val.device} edid ${val.edid} `);
        ctx.liguodata.SetStatusSuccess(); 
    }
    else{
        ctx.liguodata.SetErrorInfo("device is not encode");
    }
}
// 获取设备EDID
sdvoe.GetEDID=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    if(info.deviceinfo.baseinfo.type==0)
    {
        val.edid=info.deviceinfo.HDMI[0].source.config.edid;
        ctx.liguodata.SetData(val);
    }
    else{
        val.edid=info.deviceinfo.HDMI[0].sink[0].monitor.state.edid;
        ctx.liguodata.SetData(val);
    }
    
}
// 下载设备EDID
sdvoe.LoadEDID=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    if(info.deviceinfo.baseinfo.type==0)
    {
        val.edid=info.deviceinfo.HDMI[0].source.config.edid;
        ctx.liguodata.SetData(val);
    }
    else{
        val.edid=info.deviceinfo.HDMI[0].sink[0].monitor.state.edid;
        ctx.liguodata.SetData(val);
    }
    
}

// 上传设备升级文件
sdvoe.PutDeviceUpGradeFile=function upload_device_upgradefile(val,ctx,database)
{

    
}
// 获取升级文件列表
sdvoe.DeviceUpGradeFileList=async function(val,ctx,database)
{
    await cmd(`list firmware`).then(value=>{
        //value 是发送命令的返回结果
        value = JSON.parse(value);
        ctx.liguodata.SetData(value.result);
    });
    
}
// 网络参数设置
sdvoe.SetDeviceNetwork=async function(val,ctx,database)
{
    if(val.DHCP==false)
    {
        await cmd(`set ${val.device} ip mode manual address ${val.address} mask ${val.mask} gateway ${val.gateway}`).then(value=>{
            ctx.liguodata.SetStatusSuccess(); 
        });

    }
    else
    {
        await cmd(`set ${val.device} ip mode dhcp`).then(value=>{
            //value 是发送命令的返回结果
            
            ctx.liguodata.SetStatusSuccess(); 
        });
    }

    
}
// 网络参数获取
sdvoe.GetDeviceNetwork=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.address=info.deviceinfo.network.address;
    val.gateway=info.deviceinfo.network.gateway;
    val.mask=info.deviceinfo.network.mask;
    val.DHCP=info.deviceinfo.network.dhcp;
    ctx.liguodata.SetData(val);
    
}
// 输出模式设置
sdvoe.SetDeviceSwitchMode=async function (val,ctx,database)
{
    await cmd(`set ${val.device} video ${val.mode}`).then(value=>{
        //这里还要修改数据库和内存结构体状态
        ctx.liguodata.SetStatusSuccess(); 
    });
}
// 输出模式获取
sdvoe.GetDeviceSwitchMode=function (val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.mode =info.deviceinfo.HDMI[0].subscript[0].config.mode;
    ctx.liguodata.SetData(val);
    
}

// 获取编码器输入视频信号信息
sdvoe.GetDeviceEnCodeInVideoinfo=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.alias=info.deviceinfo.HDMI[0].streams[0].config.alias;
    val.signalstate =info.deviceinfo.HDMI[0].source[0].info.signal.video.signalestate;
    val.width =info.deviceinfo.HDMI[0].source[0].info.signal.video.width;
    val.heigth =info.deviceinfo.HDMI[0].source[0].info.signal.video.height;
    val.fps =info.deviceinfo.HDMI[0].source[0].info.signal.video.frames_per_second;
    val.color_space =info.deviceinfo.HDMI[0].source[0].info.signal.video.color_space;
    val.deep_color =info.deviceinfo.HDMI[0].source[0].info.signal.video.bies_per_pixel;
    val.scan =info.deviceinfo.HDMI[0].source[0].info.signal.video.scan_mode;
    val.aspect =info.deviceinfo.HDMI[0].source[0].info.signal.video.aspect;
    val.hdcp =info.deviceinfo.HDMI[0].source[0].info.signal.video.HDCPState;
    ctx.liguodata.SetData(val);
    
}

// 获取编码器输入音频信号信息
sdvoe.GetDeviceEnCodeInAudioinfo=function (val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.alias=info.deviceinfo.HDMI[0].streams[3].config.alias;
    val.deep_color =info.deviceinfo.HDMI[0].source[0].info.signal.audio.sampling_frequency;
    val.scan =info.deviceinfo.HDMI[0].source[0].info.signal.audio.number_of_channels;
    val.aspect =info.deviceinfo.HDMI[0].source[0].info.signal.audio.audio_encoding_type;
    ctx.liguodata.SetData(val);

    
}
// 获取编码器输入视频信号HDCP状态
sdvoe.GetDeviceEnCodeHDCPmode=function (val,ctx,database)
{
    let info = deviceMap.get(val.device);
    if(info.deviceinfo.HDMI[0].source[0].config.hdcp_support_enable==true)
    {
        if(info.deviceinfo.HDMI[0].source[0].config.hdcp_22_support_disable==true)
        {
            val.status=1.4;
        }
        else
            val.status=2.2;
    }
    else
        val.status=0;
   
    ctx.liguodata.SetData(val);
}
// 设置编码器HDCP支持能力
sdvoe.SetDeviceEnCodeHDCPmode=async function (val,ctx,database)
{
    if(val.status==1.4)
    {
        await cmd(`set ${val.device} property nodes[HDMI_DECODER:0].inputs.configuration.hdcp_support_enable true`).then(value=>{
        //     await cmd(`set ${val.device} property nodes[HDMI_DECODER:0].inputs.configuration.hdcp_22_support_disable true`).then(value=>{
        //         //这里还要修改数据库和内存结构体状态
        //        ctx.liguodata.SetStatusSuccess(); 
        //    });
        });
    }
    else if(val.status==2.2)
    {
        await cmd(`set ${val.device} property nodes[HDMI_DECODER:0].inputs.configuration.hdcp_support_enable true`).then(value=>{
        //     await cmd(`set ${val.device} property nodes[HDMI_DECODER:0].inputs.configuration.hdcp_22_support_disable false`).then(value=>{
        //         //这里还要修改数据库和内存结构体状态
        //        ctx.liguodata.SetStatusSuccess(); 
        //    });
        });
    }
    else{
        await cmd(`set ${val.device} property nodes[HDMI_DECODER:0].inputs.configuration.hdcp_support_enable false`).then(value=>{
        //     await cmd(`set ${val.device} property nodes[HDMI_DECODER:0].inputs.configuration.hdcp_22_support_disable true`).then(value=>{
        //         //这里还要修改数据库和内存结构体状态
        //        ctx.liguodata.SetStatusSuccess(); 
        //    });
        });
    }
    
    
}
// 获取解码器输入视频信号信息
sdvoe.GetDeviceDeCodeInVideoinfo=function (val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.signalstate =info.deviceinfo.HDMI[0].sink[0].info.signal.video.signalestate;
    val.width =info.deviceinfo.HDMI[0].sink[0].info.signal.video.width;
    val.heigth =info.deviceinfo.HDMI[0].sink[0].info.signal.video.height;
    val.fps =info.deviceinfo.HDMI[0].sink[0].info.signal.video.frames_per_second;
    val.color_space =info.deviceinfo.HDMI[0].sink[0].info.signal.video.color_space;
    val.deep_color =info.deviceinfo.HDMI[0].sink[0].info.signal.video.bies_per_pixel;
    val.scan =info.deviceinfo.HDMI[0].sink[0].info.signal.video.scan_mode;
    val.aspect =info.deviceinfo.HDMI[0].sink[0].info.signal.video.aspect;
    val.hdcp =info.deviceinfo.HDMI[0].sink[0].info.signal.video.HDCPState;
    ctx.liguodata.SetData(val);
    
}
// 获取解码器输出视频信号
sdvoe.GetDeviceDeCodeOutVideoinfo=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.signalstate =info.deviceinfo.HDMI[0].sink[0].info.signal.video.signalestate;
    val.width =info.deviceinfo.HDMI[0].sink[0].info.signal.video.width;
    val.heigth =info.deviceinfo.HDMI[0].sink[0].info.signal.video.height;
    val.fps =info.deviceinfo.HDMI[0].sink[0].info.signal.video.frames_per_second;
    val.color_space =info.deviceinfo.HDMI[0].sink[0].info.signal.video.color_space;
    val.deep_color =info.deviceinfo.HDMI[0].sink[0].info.signal.video.bies_per_pixel;
    val.scan =info.deviceinfo.HDMI[0].sink[0].info.signal.video.scan_mode;
    val.aspect =info.deviceinfo.HDMI[0].sink[0].info.signal.video.aspect;
    val.hdcp =info.deviceinfo.HDMI[0].sink[0].info.signal.video.HDCPState;
    ctx.liguodata.SetData(val);
    
    
}
// 获取解码器HDCP输出状态
sdvoe.GetDeviceDeCodeHDCPmode=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.status =info.deviceinfo.HDMI[0].sink[0].config.hdcp_output_mode;
    ctx.liguodata.SetData(val);
}
// 设置解码器HDCP输出状态
sdvoe.GetDeviceDeCodeHDCPmode=async function(val,ctx,database)
{
    await cmd(`set ${val.device} property nodes[HDMI_ENCODER:0].inputs.configuration.hdcp_output_mode ${val.status} `).then(value=>{
        //这里还要修改数据库和内存结构体状态
        ctx.liguodata.SetStatusSuccess(); 
    });
}
// 设备重启
sdvoe.SetDeviceRestart=async function (val,ctx,database)
{
    await cmd(`reboot ${val.device}  `).then(value=>{
        //这里还要修改数据库和内存结构体状态
        ctx.liguodata.SetStatusSuccess(); 
    });
    
}
// 设备factory
sdvoe.SetDeviceFactory=async function (val,ctx,database)
{
    await cmd(`factory ${val.device}`).then(value=>{
        //这里还要修改数据库和内存结构体状态
        ctx.liguodata.SetStatusSuccess(); 
    });
    
}
// 设置设备升级
sdvoe.SetDeviceUpgrade=async function(val,ctx,database)
{
    await cmd(`update ${val.device}  ${val.file} `).then(value=>{
        //这里还要修改数据库和内存结构体状态
        ctx.liguodata.SetStatusSuccess(); 
    });   
}
// 查看设备升级状态
sdvoe.GetDeviceUpgradeStatus=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    
}
// 获取设备延迟出声状态
sdvoe.GetDeviceDeCodeHDCPAudioDelay= function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.status =info.deviceinfo.HDMI[0].subscript[1].config.audio_delay;
    ctx.liguodata.SetData(val);
}
// 设置设备延迟出声
sdvoe.SetDeviceDeCodeHDCPAudioDelay=async function(val,ctx,database)
{
    await cmd(`set ${val.device} property subscriptions[HDMI_AUDIO:0].configuration.mute_msec ${val.status} `).then(value=>{
        //这里还要修改数据库和内存结构体状态
        ctx.liguodata.SetStatusSuccess(); 
    });
}
// 通道别名设置
sdvoe.SetDeviceChannelAliasName=function(val,ctx,database)
{
    if(val.type=="video")
    {
        info.deviceinfo.HDMI[0].stream[val.index].config.alias=val.name ;
    }
    else if(val.type=="audio"){
        if(val.index==0)
            info.deviceinfo.HDMI[0].stream[3].config.alias=val.name;
        else if(val.index==1){
            info.deviceinfo.AnalogAudio[0].config.alias=val.name;
        }
    }

    
}
// 通道别名获取
sdvoe.GetDeviceChannelAliasName=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    if(val.type=="video")
    {
        val.name =info.deviceinfo.HDMI[0].stream[val.index].config.alias;
    }
    else if(val.type=="audio"){
        if(val.index==0)
            val.name =info.deviceinfo.HDMI[0].stream[3].config.alias;
        else if(val.index==1){
            val.name =info.deviceinfo.AnalogAudio[0].config.alias;
        }
    }
    ctx.liguodata.SetData(val);
}
// 设备别名设置
sdvoe.SetDeviceAliasName=async function (val,ctx,database)
{
    let info = deviceMap.get(val.device);
    info.deviceinfo.baseinfo.alias=val.name;
    //更新数据库；
    await database.collection("Device").findOneAndUpdate({"baseinfo.id":val.device},{"$set":{"baseinfo.alias":val.name}}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo(`device ${val.device} database DeviceAliasName  update fail`);
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    }); 
}
// 设备别名获取
sdvoe.GetDeviceAliasName=function (val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.name =info.deviceinfo.baseinfo.alias;
    ctx.liguodata.SetData(val);
}
// 编码器AFV设置  视频切换时要切换对应的音频 没有做
sdvoe.SetDeviceEnCodeAFVmode=async function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    info.deviceinfo.HDMI[0].stream[0].config.afv=val.status;
    await database.collection("Device").findOneAndUpdate({"baseinfo.id":val.device},{"$set":{"HDMI.0.stream.0.config.afv":val.status}}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo(`device ${val.device} database SetDeviceEnCodeAFVmode  update fail `);
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    
}
// 编码器AFV获取
sdvoe.GetDeviceEnCodeAFVmode=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.status =info.deviceinfo.HDMI[0].stream[0].config.afv;
    ctx.liguodata.SetData(val);
}
// 设备查找状态获取
sdvoe.GetDeviceHandupmode=function(val,ctx,database)
{
    let info = deviceMap.get(val.device);
    val.status =info.deviceinfo.baseinfo.HandUp;
    ctx.liguodata.SetData(val);
}
// 设备查找状态设置
sdvoe.SetDeviceHandupmode=async function(val,ctx,database)
{
    await cmd(`set ${val.device} property configuration.locate_mode ${val.status} `).then(value=>{
        //这里还要修改数据库和内存结构体状态
        return database.collection("Device").findOneAndUpdate({"baseinfo.id":val.device},{"$set":{"baseinfo.HandUp":val.status}})
    }).then((doc)=>{
        if(doc){
            info.deviceinfo.baseinfo.HandUp=val.status;
            ctx.liguodata.SetStatusSuccess(); 
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo(`device ${val.device} database handup  update fail `);
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });;
}
// 删除设备操作
sdvoe.SetDeleteDevice=async function(val,ctx,database)
{
    // 删除某个设备的数据库信息  
    await database.collection("Device").findOneAnddelete({"baseinfo.id":val.device},{"$set":{"info.deviceinfo.baseinfo.HandUp":val.status}}).then((doc)=>{
        if(doc){
            ctx.liguodata.SetStatusSuccess();   
        }else{
            //返回错误 数据库不存在
            ctx.liguodata.SetErrorInfo(`device ${val.device} database handup  update fail `);
        }
    },(err)=>{
        console.log("error")
        console.dir(err);
    });
    

}

// 查找设备温度
sdvoe.GetDeviceTemperature=async function(val,ctx,database)
{
    //val.device
    //val.num 读几个
        //这里要读取数据库
        await database.collection("monitor").findOne({"device":val.device}).then((doc)=>{
            if(doc){
                for(let i=0;i<val.num;i++)
                {
                    //[{temp: 
                    //date:}]
                }
            }else{
                //返回错误 数据库不存在
                ctx.liguodata.SetErrorInfo(`device ${val.device} database handup  update fail `);
            }
        },(err)=>{
            console.log("error")
            console.dir(err);
        });
        ctx.liguodata.SetStatusSuccess();  
}
// function cc(){
//     return new Promise((res,rej)=>{
//         setTimeout(()=>{
//             res("good")
//         },1000);
//     })
// }
// function dd(){
//     return new Promise((res,rej)=>{
//         setTimeout(()=>{
//             res("good 111")
//         },4000);
//     })
// }
// sdvoe.test =async function(val,ctx){
//     let a = cc();
//     await a.then((msg)=>{
//         console.log(msg);
//         let b = dd();
//         return b;
//         // b.then((msg)=>{
//         //     console.log(msg);
//         //     ctx.liguodata.SetStatusSuccess();
//         // })
//     }).then((msg)=>{
//         console.log(msg);
//         ctx.liguodata.SetStatusSuccess();
//     })
//     console.log("111111111111111111111")
// }

// 以下暂不实现
// 流停止
// 流开启
// 编码器辅流设置
// 设置USB模式
// 设备绑定
// 设备解绑

// ctx.liguodata.SetStatusSuccess();
// ctx.liguodata.SetData({"sessionid":value.sessionid});
// ctx.liguodata.SetErrorInfo("no this cmd");

sdvoe.Init = function(database){
   // console.dir(database)
    Monitor(database);
    blueriver_api_init();
    
}
module.exports = sdvoe;