const USBinfo = require("./usb");
const net_UDP  = require('dgram');
let server_UDP;
const Status = ["unknow","connected","register","available"];
const statusinfo =new Map();
(function InitStatue(){
    Status.forEach((val,index)=>{
        statusinfo.set(val,index);
    });
}());
class DeviceInfo{
    constructor(id,database){
        this.id = id;
        this.database=database;
        this.status = Status[0];
        this.deviceinfo = {};
        this.deviceinfo.baseinfo = {}
        this.deviceinfo.baseinfo.module = "sdvoe";
        this.deviceinfo.baseinfo.temperature = [];
    }
    StatusChange(value){
        let index = statusinfo.get(value);
        if((typeof index) == "number"){
            this.status = value;
        }
    }
    //未注册设备上线过程
    DeviceRegister(val){
        let usb_active={};
        val.nodes.forEach(value=>{
            if(value.type == "USB_ICRON"){
                usb_active=value.status.chip_present;
            }
        });
        let network={};
        val.nodes.forEach(value=>{
            if(value.type == "NETWORK_INTERFACE"){
                network.ip=value.configuration.ip.address;
                network.mask=value.configuration.ip.mask;
                network.gateway=value.configuration.ip.gateway;
                network.dhcp=value.configuration.ip.mode;
            }
        });


        let baseinfo = this.deviceinfo.baseinfo ;
        let {identity:{firmware_version,is_receiver}}=val;
        let {capabilities:{ hdmi_inputs,
                            hdmi_outputs,
                            usb_icron,
                            uarts,
                            infrared_inputs,
                            infrared_outputs,
                            multich_audio_inputs,
                            multich_audio_outputs,
                            stereo_audio_inputs,
                            stereo_audio_input_outputs,
                            stereo_audio_outputs,
                            color_generator_force,
                            frame_rate_divider,
                            hdmi_audio_downmix,
                            thumbnail,
                            overlay,
                            scaler,
                            video_processing,
        }} = val ;
        let {status:{
                        active,
                        point_to_point,
                        update_in_progress,
                        temperature,
                        error_status
        }}= val ;
        let {configuration:{locate_mode}} = val ;

        baseinfo.id = this.id ;
        baseinfo.firmware_version = firmware_version ;
        baseinfo.type = Number(is_receiver) ;
        baseinfo.alias = this.id ;
        baseinfo.active = active ;
        baseinfo.HandUp = locate_mode ;
        {
            let date = new Date().toLocaleString().split(" ").slice(0,2);
            date=date.join(" ");
            let tem = {temperature,date}
            baseinfo.temperature.push(tem);
        }
        let {streams,nodes,subscriptions} = val;
        {
            let video = {};
            video.count = hdmi_inputs||hdmi_outputs;
            if(video.count){
                video.ability = {};
                {
                    color_generator_force?video.ability.color_generator=color_generator_force:null
                    frame_rate_divider?(video.ability.frame_rate=frame_rate_divider):null;
                    hdmi_audio_downmix?(video.ability.hdmi_audio_downmix=hdmi_audio_downmix):null;
                    thumbnail?(video.ability.thumbnail=thumbnail):null;
                    overlay?(video.ability.bitmap_overlay=overlay):null;
                    scaler?(video.ability.scaler = scaler):null;
                    // video.ability.video_processing = video_processing || null ;
                }
                let func ;
                if(baseinfo.type)
                {
                    func = this.GetDecodeDeviceVideoInfo;
                }else{
                    func = this.GetEncodeDeviceVideoInfo;
                }
                let device = [];
                for(let i = 0 ; i < video.count ; i++ ){ 
                    let data = func.call(this,video.ability,streams,nodes,subscriptions,i);
                    if(data){
                        device.push(data);
                    }
                }
                if(!baseinfo.type){
                    device[0].streams[0].config.afv = true; 
                }else{   
                    let source = {       
                            mac:null,
                            mode:"genlock",
                            template:null   
                    };
                    device[0].subscript[0].config = source;
                    device[0].subscript[1].config = {
                        mac:null,
                        index:2,
                        audio_delay:600
                    };
                }
                this.deviceinfo.HDMI = device ;  
            }
            {
                let audio = {};
                let func = [];
                let device = [];
                if(baseinfo.type)
                {
                    audio.count = stereo_audio_outputs ;
                    func = this.GetAudioDecodeInfo;             
                }else{
                    audio.count = stereo_audio_input_outputs ;
                    func = this.GetDDRAudioInfo;
                }
                if(audio.count){
                    for(let i = 0 ; i < audio.count ; i++ ){ 
                        let data;
                        if(stereo_audio_outputs){
                            data = func.call(this,subscriptions);
                        }else{
                            data = func.call(this,streams,nodes,subscriptions);
                        }
                        if(data){
                            // console.dir(data)
                            let conf = data.config;
                            if(conf.direction ==="INPUT"){
                                
                            }else{
                                conf.source = {};
                                let source  = conf.source
                                source.mac = null;
                                source.select = 3;
                            }
                            device.push(data); 
                        }
                    }
                    this.deviceinfo.AnalogAudio = device;
                }
            }
            {
                if(usb_active){
                  
                    this.deviceinfo.USB = this.GetDeviceUSBInfo(nodes);
                    baseinfo.USBactive = true ;
                }
                else{
                    baseinfo.USBactive = false ;
                }
            }
            {
                if(uarts){

                }
            }
            {
                if(infrared_inputs){

                }
                if(infrared_outputs){

                }
            }
        }
        // this.GetStaticinfo();
    }
    //已注册设备上线过程
    DeviceConnected(val){
        let usb_active={};
        val.nodes.forEach(value=>{
            if(value.type == "USB_ICRON"){
                usb_active=value.status.chip_present;
            }
        });
        let network={};
        val.nodes.forEach(value=>{
            if(value.type == "NETWORK_INTERFACE"){
                network.ip=value.configuration.ip.address;
                network.mask=value.configuration.ip.mask;
                network.gateway=value.configuration.ip.gateway;
                network.dhcp=value.configuration.ip.mode;
            }
        });
        let baseinfo = this.deviceinfo.baseinfo ;
        let {identity:{firmware_version,is_receiver}}=val;
        let {capabilities:{ hdmi_inputs,
                            hdmi_outputs,
                            usb_icron,
                            uarts,
                            infrared_inputs,
                            infrared_outputs,
                            multich_audio_inputs,
                            multich_audio_outputs,
                            stereo_audio_inputs,
                            stereo_audio_input_outputs,
                            stereo_audio_outputs,
                            color_generator_force,
                            frame_rate_divider,
                            hdmi_audio_downmix,
                            thumbnail,
                            overlay,
                            scaler,
                            video_processing,
        }} = val ;
        let {status:{
                        active,
                        point_to_point,
                        update_in_progress,
                        temperature,
                        error_status
        }}= val ;
        let {configuration:{locate_mode}} = val ;

        baseinfo.id = this.id ;
        baseinfo.firmware_version = firmware_version ;
        baseinfo.type = Number(is_receiver) ;
        baseinfo.alias = this.id ;//database
        baseinfo.active = active ;
        baseinfo.HandUp = locate_mode ;//database
        {
            let date = new Date().toLocaleString().split(" ").slice(0,2);
            date=date.join(" ");
            let tem = {temperature,date}
            baseinfo.temperature.push(tem);
        }
        let {streams,nodes,subscriptions} = val;
        {
            let video = {};
            video.count = hdmi_inputs||hdmi_outputs;
            if(video.count){
                video.ability = {};
                {
                    color_generator_force?video.ability.color_generator=color_generator_force:null
                    frame_rate_divider?(video.ability.frame_rate=frame_rate_divider):null;
                    hdmi_audio_downmix?(video.ability.hdmi_audio_downmix=hdmi_audio_downmix):null;
                    thumbnail?(video.ability.thumbnail=thumbnail):null;
                    overlay?(video.ability.bitmap_overlay=overlay):null;
                    scaler?(video.ability.scaler = scaler):null;
                    // video.ability.video_processing = video_processing || null ;
                }
                let func ;
                if(baseinfo.type)
                {
                    func = this.GetDecodeDeviceVideoInfo;
                }else{
                    func = this.GetEncodeDeviceVideoInfo;
                }
                let device = [];
                for(let i = 0 ; i < video.count ; i++ ){ 
                    let data = func.call(this,video.ability,streams,nodes,subscriptions,i);
                    if(data){
                        device.push(data);
                    }
                }
                if(!baseinfo.type){
                    device[0].streams[0].config.afv = true; //database
                }else{   
                    let source = {       
                            mac:null,//database
                            mode:"genlock",//database
                            template:null   //database
                    };
                    device[0].subscript[0].config = source;//database
                    device[0].subscript[1].config = {
                        mac:null,//database
                        index:2,//database
                    };
                }
                this.deviceinfo.HDMI = device ;  
            }
            {
                let audio = {};
                let func = [];
                let device = [];
                if(baseinfo.type)
                {
                    audio.count = stereo_audio_outputs ;
                    func = this.GetAudioDecodeInfo;             
                }else{
                    audio.count = stereo_audio_input_outputs ;
                    func = this.GetDDRAudioInfo;
                }
                if(audio.count){
                    for(let i = 0 ; i < audio.count ; i++ ){ 
                        let data;
                        if(stereo_audio_outputs){
                            data = func.call(this,subscriptions);
                        }else{
                            data = func.call(this,streams,nodes,subscriptions);
                        }
                        if(data){
                            // console.dir(data)
                            let conf = data.config;
                            if(conf.direction ==="INPUT"){
                                
                            }else{
                                conf.source = {};
                                let source  = conf.source
                                source.mac = null;//database
                                source.select = 3;//database
                            }
                            device.push(data); 
                        }
                    }
                    this.deviceinfo.AnalogAudio = device;
                }
            }
            {

                //USB 信息全部从数据库中获取
 
            }
            {
                if(uarts){

                }
            }
            {
                if(infrared_inputs){

                }
                if(infrared_outputs){

                }
            }
        }
        
    }
    GetDeviceHDMIStateInfo(value,sources){
        let channel = [];
        const Allowtype = ["HDMI","THUMBNAIL"];
        const type = "HDMI";
        for(let i = 0 ; i< value.length ; i++){
            let data = value[i];
            if(Allowtype.includes(device.type)){
                let device = {};
                // device.type = type ;
                device.index = data.index;
                device.config = {};
                device.signal = {};
                let {configuration:conf,status:{state},source} = data;
                let {enable,remove_audio} = conf;
                device.config.enable = enable;
                device.config.remove_audio = remove_audio;
                device.state = state ;
                switch(source.ref_type){
                    case "HDMI_DECODER":{
                        device.signal = {} ;
                        this.GetHDMIDecoderInfo(device.config,device.signal,sources);
                        break;
                    }
                    case "SCALER":{
                        device.signal = {} ;
                        this.GetScalerInfo(device.config,device.signal,sources);
                        break;
                    }
                    case "THUMBNAIL":{
                        device.signal = {} ;
                        this.GetThumbnailInfo(device.config,device.signal,sources);
                        break ;
                    }
                    default :{
                        console.log("have know HDMI source");
                    }
                }
                channel.push(device);
            }
        }
        return channel;
    }
    GetHDMIDecoderInfo(conf,signal,data){
        const type = "HDMI_DECODER";
        for(let i = 0 ; i <data.length; i++){
            let val = data[i];
            if(val.type == type){
                let temp = val.configuration;
                for(let value in temp){
                    conf[value]=temp[value];
                }
                let{
                    source_stable,
                    hdcp_version
                } = val.status;
                signal.hdcp_version = hdcp_version ;
                signal.source_stable = source_stable;
                let videoinfo = val.status.video;
                for(let i in videoinfo){
                    // console.log(`have value ${i}`);
                    signal[i] = videoinfo[i];
                }
            }
        }
    }
    GetScalerInfo(conf,signal,data){
        const type = "SCALER";
        for(let i = 0 ; i <data.length; i++){
            let val = data[i];
            if(val.type == type){
                let temp = val.configuration;
                for(let value in temp){
                    conf[value]=temp[value];
                }
                let videoinfo = val.status.video;
                for(let i in videoinfo){
                    signal[i] = videoinfo[i];
                }
            }
        }
    }
    GetThumbnailInfo(conf,signal,data){
        const type = "THUMBNAIL";
        for(let i = 0 ; i <data.length; i++){
            let val = data[i];
            if(val.type == type){
                let temp = val.configuration;
                for(let value in temp){
                    conf[value]=temp[value];
                }
                let videoinfo = val.status;
                for(let i in videoinfo){
                    signal[i] = videoinfo[i];
                }
            }
        }
    }
    GetDeviceAudioStateInfo(value,sources){
        let channel = [];
        const Allowtype = ["HDMI_AUDIO","STEREO_AUDIO"];
        const type = "HDMI"
        for(let i = 0 ; i< value.length ; i++){
            let data = value[i];
            if(Allowtype.includes(data.type)){
                let device = {};
                device.index = data.index;
                device.config = {};
                device.signal = {};
                let {configuration:conf,status:{state},source} = data;
                let {enable} = conf;
                device.config.enable = enable;
                device.state = state ;
                switch(source.ref_type){
                    case "HDMI_DECODER":{
                        device.signal = {} ;
                        this.GetHDMIAudioInfo(device.config,device.signal,sources);
                        break;
                    }
                    case "SCALER":{
                        device.signal = {} ;
                        this.GetStereoAudioInfo(device.config,device.signal,sources);
                        break;
                    }
                    default :{
                        console.log("have know Audio source");
                    }
                }
                channel.push(device);
            }
        }
        return channel;
    }
    GetHDMIAudioInfo(conf,signal,data){

    }
    GetStereoAudioInfo(conf,signal,data){

    }
    GetEncodeDeviceVideoInfo(ability,streams,nodes,subscriptions,i){
        let device = {};
        device.source = this.GetHDMISourceInfo(nodes,i);
        if(device.source){
            device.ability = this.GetVideoProcessAbility(ability,nodes);
            device.streams = this.GetOutVideoStream(streams,nodes,device.ability);////database
            if(ability.hdmi_audio_downmix){
                let data  = this.GetHDMIAudioStream(streams);
                if(data){
                    device.streams.push(data);
                }
            }
            return device;
        }
    }
    GetDecodeDeviceVideoInfo(ability,streams,nodes,subscriptions,i){
        let device = {};
        device.sink = this.GetHDMISinkInfo(nodes,i);
        if(device.sink){
            device.ability = this.GetVideoProcessAbility(ability,nodes);
            device.subscript = this.GetInVideoStream(subscriptions);
            return device;
        }
    }
    GetHDMISourceInfo(nodes,index){
        let info = [];
        const type = "HDMI_DECODER";
        let len = nodes.length;
        for(let i = 0 ; i < len ;i++){
            let node = nodes[i];
            if((node.type==type)&&(index==node.index)){
                let device = {};
                device.config = node.configuration;
                let state = node.status;
                device.info = {};
                device.info.signal = {};
                {
                    device.info.signal.video = {};
                    let signal = device.info.signal.video;
                    signal.signalstate =state.source_stable;
                    signal.aspect=state.video_details.picture_aspect;
                    if(signal.signalstate)
                    {
                        for(let i in state.video){
                            signal[i]  = state.video[i];
                        }
                        signal.HDCPState = state.hdcp_version;
                    }else{

                    }
                    let hasaudio = state.has_audio_details;
                    if(hasaudio){
                        device.info.signal.audio = {};
                        let signal = device.info.signal.audio;
                        for(let i in state.audio_details){
                            signal[i] = state.audio_details[i];
                        }
                        let moreinfo = state.audio_details_extended
                        if(moreinfo){
                            signal.audio_encoding_type = state.audio_details_extended.audio_encoding_type;
                        }
                    }
                }    
                info.push(device); 
            }   
        }
        return info.length?info:null ;
    }
    GetHDMISinkInfo(nodes,index){
        let info=[];
        const type = "HDMI_ENCODER";
        let len = nodes.length;
        let sink;
        for(let i = 0 ; i < len ;i++){
            let node = nodes[i];
            if((node.type==type)&&(index==node.index)){
                let device = {};
                device.config = node.configuration;
                let state = node.status;
                device.info = {};
                device.info.signal = {};
                {
                    device.info.signal.video = {};
                    let signal = device.info.signal.video;
                    signal.signalstate =state.source_stable;
                    signal.aspect=state.video_details.picture_aspect;
                    if(signal.signalstate)
                    {
                        for(let i in state.video){
                            signal[i]  = state.video[i];
                        }
                        signal.HDCPState = state.hdcp_version;
                    }else{
                    }
                    let hasaudio = state.has_audio_details;
                    if(hasaudio){
                        device.info.signal.audio = {};
                        let signal = device.info.signal.audio;
                        for(let i in state.audio_details){
                            signal[i] = state.audio_details[i];
                        }
                        let moreinfo = state.audio_details_extended
                        if(moreinfo){
                            signal.audio_encoding_type = state.audio_details_extended.audio_encoding_type;
                        }
                    }
                }    
                info.push(device);
            }   
        }
        if(info.length){
            for(let i = 0 ; i<len; i++){
                const type = "HDMI_MONITOR";
                let node = nodes[i];
                if(node.type == type){
                    console.dir(node.status)
                    sink = this.GetNodeInfo(node,"video");
                    break;
                }
            }
            for(let i= 0 ; i<info.length ; i++){
                let node = info[i];
                node.monitor = sink;
            }
        }
        return info.length?info:null ;
    }
    GetVideoProcessAbility(ability,nodes){
        let abi ={};
        for(let i in ability){
            for(let n = 0 ; n<nodes.length ; n++){
                let node  = nodes[n];
                let str = node.type.toLocaleLowerCase();
                if(str.startsWith(i)){
                    abi[str] = this[i](node);
                    break;
                }
            }
        }
        return abi;
    }
    color_generator = function(value){
        // console.log("color_generator_force");
        let {configuration,status} = value;
        return {configuration,status}
    }
    bitmap_overlay = function(value){
        // console.log("bitmap_overlay");
    }
    frame_rate = function(value){
        // console.log("frame_rate_divider");
        let {configuration,status} = value;
        return {configuration,status}
    }
    hdmi_audio_downmix = function(value){
        // console.log("hdmi_audio_downmix");
        let {configuration,status} = value;
        return {configuration,status}
    }
    thumbnail = function(value){
        // console.log("thumbnail");
        let {configuration,status} = value;
        // console.dir({configuration,status});
        return {configuration,status};
    }
    overlay = function(value){
        // console.log("overlay");
        let {configuration,status} = value;
        return {configuration,status}
    }
    scaler = function(value){
        // console.log("scaler");
        let {configuration,status} = value;
        return {configuration,status}
    }
    GetOutVideoStream(streams,nodes,ability){
        let channel = [];
        const Allowtype = ["HDMI","THUMBNAIL"];
        const type = "HDMI";
        let scaler =ability.scaler;
        let thumbnail = ability.thumbnail_generator;
        streams.forEach(value=>{
            if(Allowtype.includes(value.type)){
                let {configuration,source} = value ;
                let conf = {}
                // console.log(`the value.type is ${value.type} and the value.index is ${value.index}`)
                if(value.type ==type){
                    if(value.index){
                        let data = this.GetNode(nodes,"scaler");
                        conf = scaler.configuration||{};
                        if(data){
                            conf.frame_rate_divider = !!(data.inputs[0].configuration.source.value);
                        }  
                    }else{
                        conf.frame_rate_divider = !!(source.value);//database
                        // conf.avf = true ;
                    }
                }else{
                    conf = thumbnail.configuration||{};//database
                }
                conf.alias = `${value.type}-${value.index+1}`;//database
                conf.enable = configuration.enable;//database
                conf.HasAudio = !configuration.remove_audio || null;//database
                channel.push({type:"video",config:conf});
            }
        });
        return channel;
    }
    GetInVideoStream(streams){
        let channel = [];
        const Allowtype = ["HDMI","HDMI_AUDIO"];
        const type = "HDMI";
        streams.forEach(value=>{
            if(Allowtype.includes(value.type)){
                let data= this.GetSubscript(value);
                let conf = data.configuration||{};
                conf.alias =`${value.type}-${value.index+1}`;//database
                if(value.type===type ){
                    if(value.index ===0){
                        data.type="video";
                        channel.push(data);
                    }
                }else{
                    data.type="audio";
                    channel.push(data);
                }            
            }
        });
        return channel;
    }
    GetHDMIAudioStream(streams){
        const Allowtype = ["HDMI_AUDIO"];
        let data;
        streams.forEach(value=>{
            if(Allowtype.includes(value.type)){
                let {configuration,status,source} = value ;
                let conf = {};
                conf.enable = configuration.enable;
                let choices = configuration.source || null;
                if(choices){
                    conf.choices = {} ;
                    conf.choices.value = choices.value;
                    conf.choices.input = {};
                    choices.choices.forEach((value)=>{
                        let {ref_type:type,ref_index:index} = value.details
                        conf.choices.input[value.value] = {type,index};
                    })
                }
                data={type:"audio",conifg:conf}
                
            }
        });
        return data;
    }
    GetDDRAudioInfo(streams,nodes,subscriptions){
        let device;
        const type = "STEREO_AUDIO_INPUT_OUTPUT";
        nodes.forEach((value)=>{
            if(value.type == type){
                let data = null;
                let flag = false ;
                let direction = value.configuration.direction;//database
                if(direction === "INPUT"){
                    data = this.GetAudioEncodeInfo(streams,nodes);
                }else if(direction === "OUTPUT"){
                    data = this.GetAudioDecodeInfo(subscriptions,nodes);
                    flag = true ;
                }else{

                }
                if(data){
                    if(flag){
                        device = data;
                    }else{
                        device = data;
                    }
                    device.ability = {};
                    device.ability.direction = true;
                }
            }
        })
        return device;  
    }
    GetAudioEncodeInfo(streams){
        const type = "STEREO_AUDIO";
        let data;
        let direction = "INPUT";
        streams.forEach((value)=>{
            if(value.type == type){
                let {configuration} = value;
                let conf = {}
                conf.enable = configuration.enable;//database
                conf.direction = direction;//database
                conf.alias = "AnanlogAudioInput";//database
                data = {type:"audio",config:conf}
            }
        });
        return data;
    }
    GetAudioDecodeInfo(subscription){
        const type = "STEREO_AUDIO";
        let data;
        let direction = "OUTPUT";
        subscription.forEach((value)=>{
            if(value.type == type){
                let val
                val = this.GetSubscript(value,"audio");
                if(val){
                    data = {}
                    data.config = {};
                    data.config.enable = val.config.enable;//database
                    data.config.alias = "AnanlogAudioOutput";//database
                }
                if(data){
                    data.config.direction = direction ; //database
                }
            }
        });
        return data;
    }
    GetAudioNodeInfo(){

    }
    GetAudioStreamInfo(){

    }
    GetAudioSubscriptInfo(){

    }
    GetSubscript(value,type){
        let{configuration} = value
        let conf = {};
        for(let i in configuration){
            if(i==="address"){
                continue;
            }
            conf[i] = configuration[i];
        }
        return  {type,config:conf};
    }
    GetNodeInfo(value,type){
        let{configuration:conf,status} = value
        let state = status;
        return  {type,config:conf,state};
    }
    GetNode(nodes,type,index=0){
        type = type.toLocaleUpperCase();
        for(let i =0; i<nodes.length ;i++){
            let node = nodes[i];
            if(node.type == type && node.index == index){
                return node;
            }
        }
    }
    GetStream(value){
        let{type,index,configuration,status} = value
        switch(type){
            case "HDMI":{
                break ;
            }
            case "THUMBNAIL":{
                break;
            }
            case "HDMI_AUDIO":{
                break;
            }
            case "STEREO_AUDIO":{
                break;
            }
        }
        return  {type,config:conf,state};
    }
    GetStreamDiff(dist){
        let now = this.GetStream(dist);
        let diff;
        switch(type){
            case "HDMI":{
                break ;
            }
            case "THUMBNAIL":{
                break;
            }
            case "HDMI_AUDIO":{
                break;
            }
            case "STEREO_AUDIO":{
                break;
            }
        }
        return diff;
    }
    GetStaticinfo(){
        let device_id = this.id
        let deviceinfo = this.deviceinfo;
        let device={} ;
        for(let i in deviceinfo){
            switch(i){
                case "AnalogAudio":
                case "baseinfo":{
                    device[i] = deviceinfo[i];
                    break;
                }
                case "HDMI":{
                    let ability = {} ; 
                    let {sink:decode,ability:abi,subscript,streams,source:encode} = deviceinfo[i][0];
                    let config ={};
                    for(let n in abi){
                        ability[n] ={};
                        if(abi[n]){
                            let {configuration:config} = abi[n];
                            ability[n] = {config};
                        }
                    }
                    if(decode){
                        config = decode[0].config;
                        let sink = {config};
                        device[i] = {ability,subscript,sink}
                    }
                    else{
                        config = encode[0].config;
                        let source = {config};
                        device[i] = {ability,streams,source}
                    }
                    break;
                }
                case "USB":{
                    device[i]=deviceinfo.USB;
                    break;
                }
                default :{
                    console.log(`have another device`);
                }
            }
        } 
        
        device.device_id = device_id;
        return device;
    }
    GetDiff(value){
        let data;
        console.log(`the device ${this.id} status is ${this.status}`);
        console.log(`this.deviceinfo.type is ${this.deviceinfo.baseinfo.type}`);
        if(this.deviceinfo.baseinfo.type){
            console.log(`decode`);
            data = this.GetHDMISinkInfo(value.nodes,0);
            this.deviceinfo.HDMI[0].sink[0].info = data[0].info
            this.deviceinfo.HDMI[0].sink[0].monitor = data[0].monitor||null;
        }
        else{
            console.log(`encode`);
            data = this.GetHDMISourceInfo(value.nodes,0);
            this.deviceinfo.HDMI[0].source[0].info = data[0].info;
        } 
        
    }

     USBinfoInit(value){
        let {nodes} = value;
       
        let device={};
        let dev_usb={};     
        this.deviceinfo.USB = this.GetDeviceUSBInfo(nodes);

        server_UDP = net_UDP.createSocket("udp4");
        let data=[0x2F,0x03,0xF4,0xA2,0x01,0x00,0x00,0x00,0x00,0x00];
        data=Buffer.from(data);
        server_UDP.on("listening",()=>{
            console.log("listening ");
        });
        server_UDP.on("message",(data,reio)=>{
            console.log("the data is "+data.toString("hex"));
            console.log("the remoote info is " + reio.address);
            let mac= data.slice(10,16);
            let ip =data.slice(16,20);
            if(mac.toString("hex")==this.deviceinfo.USB.USBmac)
            {
                 this.dev_usb = new USBinfo(value,mac.toString("hex"),ip,this.database);
                 device=this.deviceinfo.USB;
                 device.pair={};
                 device.pair.pair_status=this.dev_usb.pair_status;
                 device.pair.pair_device=this.dev_usb.pair_device_id;
                 device.pair.pair_dev_type=this.dev_usb.pair_dev_type;
                 device.pair.pair_mac=this.dev_usb.pair_mac_addr;
                 
                // this.database.collection("jidevice").findOneAndUpdate({"baseinfo.id":this.device_mac},{"$set":{"USB":device}}).then((doc)=>{
                //     console.log("USB   good   change database")
                // },(err)=>{
                //     console.log("databse error");
                // }).catch(err=>{
                //     console.dir(err);
                // }) 
            }
        });
        server_UDP.send(data,6137,"192.168.20.255",(err)=>{
            if(err){
                console.log("have error"+err);
            }
            else{
                console.log("connect good");
            }
        });
    }
    GetDeviceUSBInfo(nodes){
        const type = "USB_ICRON";
        let device={};
        nodes.forEach((value)=>{
        if(value.type == type){
            let data = null;
            let flag = false ;
            device.mode = value.configuration.extender_type;
            device.USBmac = value.status.mac_address;
            device.alias = "USB_"+`${this.id}`;
            device.pair={};
            device.pair.pair_status=false;
            device.pair.pair_device=null;
            device.pair.pair_dev_type=null;
            device.pair.pair_mac=null;
            }
        });
        return device ;
    }    
}

module.exports = DeviceInfo;