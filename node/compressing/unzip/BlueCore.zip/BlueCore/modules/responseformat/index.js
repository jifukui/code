class ResponsrFormat{
    constructor(){
        this.status = "FAILED";
        this.result={};
        this.process = [];
        this.error = null;
        this.Timestamp = null;
    }
    SetCommand(value){
        this.result.command= value;
    }
    SetStatusSuccess(){
        this.status="SUCCESS";
    }
    SetData(value){
        this.result.data=value;
        this.SetStatusSuccess();
        
    }
    SetTimeStamp(){
        this.Timestamp= Date.now();
    }
    SetErrorInfo(value){
        console.dir(this);
        console.log("hello good game")
        this.error = value;
    }
    SetProcess(value){
        this.process.push(value);
    }
    SetProcessHead(value){
        this.process.unshift(value);
    }
}
module.exports = ResponsrFormat;