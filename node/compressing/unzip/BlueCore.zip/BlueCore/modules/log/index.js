const syslog = require("syslog-client");
const config = require("../../Config");
const options={
    // syslogHostname:"liguo_sdvoe",
    appName:"Blue_Core",
	transport: syslog.Transport.Tcp,
	port:514,
	facility:syslog.Facility.Local7,
	severity:syslog.Severity.Debug,
	rfc3164:false,
	dateFormatter:function(){
		return this.toTimeString().split(" ")[0];
	}
}
const logger = syslog.createClient(config.ip,options);
function logInfo(msg) {
    logger.log(`Info:${msg}`,{
        severity:syslog.Severity.Info
    },LogError);
}
function logDebug(msg) {
    logger.log(`Debug:${msg}`,{
        severity:syslog.Severity.Debug
    },LogError);
}
function logError(msg) {
    logger.log(`Error:${msg}`,{
        severity:syslog.Severity.Error
    },LogError);
}
logger.on("error",(err)=>{
    console.log(`Logger have error ${err}`);
});
logger.on("close",()=>{
    console.log("the device have closed")
})
function LogError(msg) {
    if(msg){
        console.log(`The logger have error is ${msg}`)
    }
}
module.exports ={logInfo,logDebug,logError};
