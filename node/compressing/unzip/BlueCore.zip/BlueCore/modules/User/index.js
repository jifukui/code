class User{
    constructor(){
        
    }
}