const path = require("path");
const fs = require("fs");
const Koa = require("koa");
const jwt = require("koa-jwt");
const static = require('koa-static-cache')
const LRU = require('lru-cache');
const Route = require("@koa/router");
const koaBody = require("koa-body");

const Logger = require("./modules/log/index");
const datacore = require("./modules/datacore/index");
const response = require("./modules/responseformat/index");
let files = new LRU({ max: 100 })
const app = new Koa();
const router = new Route();
datacore.Init();
app.use(async (ctx,next)=>{
    let command = {};
    let error;
    const start = Date.now();
    ctx.liguostart =start;
    if(ctx.url==="/"){
        ctx.redirect("login.html");
    }
    if(ctx.method==="POST"){
        ctx.liguodata = new response();
    }
    await next().catch((err)=>{
        console.log(`the error is ${err}`);
        error = err;
        if(ctx.method==="POST"){
            ctx.liguodata.SetErrorInfo(err.message);
        }else{
            if(err.status==401){
                ctx.body=err.message
            }
        }
    });
    if(ctx.status===404){
        ctx.redirect("login.html");
    }else if((ctx.status/100)==5 && ctx.method==="POST"){
        ctx.status = 200;
        ctx.liguodata.SetErrorInfo("Have something wrong");
    }
    if(ctx.method==="POST" && ctx.url!="/upload"){
        try{
            command.type = ctx.request.body.command.type;
            command.command = ctx.request.body.command.command;
            command.data = ctx.request.body.command.data;
            ctx.liguodata.SetCommand(command);
            if(ctx.request.body.track){
                ctx.liguodata.SetProcessHead({"start":ctx.liguostart});
                ctx.liguodata.SetProcess({"end":Date.now()});
            }
        }catch(err){
            error = err;
            console.log("have get error " +err);
        }finally{
            ctx.liguodata.SetTimeStamp();
            ctx.status = 200;
            ctx.body = ctx.liguodata;
        }
    }
    const end = Date.now();
    // if(ctx.method =="GET"){
    //     if(!error){
    //         Logger.logInfo(`${ctx.method}  ${ctx.url}  ${end-start}ms  ${ctx.response.length} Bytes`)
    //     }else{
    //         Logger.logError(`${ctx.method}  ${ctx.url}  ${end-start}ms ${err}`)
    //     }
    // }else{
    //     if(!error){
    //         Logger.logInfo(`${ctx.method}  ${ctx.url}  ${end-start}ms  ${ctx.response.length} Bytes \
    //         ${command.type} ${command.command} \
    //         ${JSON.stringify(command.data)}`);
    //     }else{
    //         Logger.logError(`${ctx.method}  ${ctx.url}  ${end-start}ms ${err}`)
    //     }
    // }
    if(!error){
        Logger.logInfo(`${ctx.method}  ${ctx.url}  ${end-start}ms  ${ctx.response.length} Bytes`);
    }else{
        Logger.logError(`${ctx.method}  ${ctx.url}  ${end-start}ms ${error}`)
    }
});
app.use(jwt({getToken,secret}).unless({
    path:["/login.html",
    "/axios.js",
    "/login",
    "/favicon.ico",
    "/login_back.jpg",
    "/jquery-3.5.1.min.js",
    "/login1.html",
    RegExp("^/css/*"),
    RegExp("^/js/*"),
    RegExp("^/fonts/*"),
    RegExp(".html$"),
    "/device/sdvoe",
    "/upload"
    ]
}));
app.use(static(path.join(__dirname,"static"),{
    maxAge:24*60*60,
    buffer:true,
    gzip:true,
    usePrecompiledGzip:true,
    dynamic:true,
    preload:true
},files));
app.use(koaBody({
    multipart: true,
    formidable: {
        maxFileSize: 20 * 1024 * 1024 ,  
        multipart: true,
        uploadDir: __dirname + '/uploads'
    }
}));
app.use(router.routes());
router
    .get("/",()=>{
        console.log("jifukui");
    })
    .post("/login",async(ctx,next)=>{
        await datacore.login(ctx);
        await next();
    })
    .post("/logout",async(ctx,next)=>{
        await datacore.logout(ctx);
        await next();
    })
    .post("/device/sdvoe",async(ctx,next)=>{
        // console.log("deivcei sdvoe 1111")
        await datacore.sdvoe(ctx);
        // console.log("deivcei sdvoe 222")
        await next();
        // console.log("deivcei sdvoe 33333")
    })
    .post("/upload",async(ctx,next)=>{
        let files = ctx.request.files.UPLOAD;
        const reader = fs.createReadStream(files.path);
        let filepath = path.join(__dirname,"../","BlueCore.zip");
        const writer = fs.createWriteStream(filepath);
        reader.pipe(writer);
        fs.unlink(files.path,(err)=>{
            if(err){
                console.log(`have error ${err}`);
            }else{
                console.log("good upload file ");
            }
        })
		//process.stdout.write("upload");
		setTimeout(()=>{
			process.exit(1);
		},1000);
        ctx.body={
            status:"good"
        }
    })
app.listen(8000,(err)=>{
    if(err){
        console.log("have error "+err);
    }else{
        console.log("stat success");
    }
});

app.on("error",(err)=>{
    console.log(`on error is ${err.status}`);
})

function getToken(ctx,opt){
    if(ctx.header.sessionid){
        return ctx.header.sessionid;
    }else{
        ctx.throw(401, 'Authorization error');  
    } 
}
function secret(head,body){
    let flag = false;
    let name,id;
    try{
        name = body.name;
        id = body.jti
    }catch(err){
        flag =true;
    }finally{
        if(!flag){
            let pid=datacore.user.get(name);
            if(id===pid){
                return "486e26c3afca7058";
            }
        }
    }
}
