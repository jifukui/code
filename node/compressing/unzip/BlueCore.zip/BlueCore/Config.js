const SystemConfig={
    ip :"192.168.20.221",
    sdvoeport:6970,
    databaseport:27017
}
module.exports=SystemConfig;